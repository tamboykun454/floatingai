# Floating AI (Android)

Robot monolit melayang di atas aplikasi lain. Tap untuk buka chat, geser untuk pindah.
Layar robot berkedip saat AI sedang berpikir.

## Cara pakai
1. Pasang Android Studio (gratis), lalu File > Open dan pilih folder FloatingAI ini.
2. Tunggu Gradle sync selesai (pertama kali butuh internet dan agak lama).
3. Di HP: Settings > About phone > ketuk Build number 7x, lalu aktifkan
   Developer options > USB debugging. Colok ke laptop.
4. Tekan tombol Run (segitiga hijau).
5. Ambil API key gratis di https://aistudio.google.com, tempel di aplikasi,
   tekan Simpan key.
6. Tekan "Nyalakan gelembung", izinkan "tampil di atas aplikasi lain",
   lalu tekan "Nyalakan gelembung" sekali lagi.

## Catatan
- Paket gratis ada batas pemakaian dan bisa berubah.
- Kalau error 404 soal model, ganti konstanta MODEL di OverlayService.kt.
- Jangan bagikan APK yang sudah berisi API key milikmu.
- Kalau Android Studio menawarkan update versi Gradle/plugin, boleh diterima.
