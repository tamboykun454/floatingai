package com.example.floatingai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Robot monolit: balok tegak yang terdiri dari beberapa lempeng.
 * Digambar lewat kode, jadi tidak butuh file gambar.
 * Desain sederhana bergaya robot monolit, bukan replika resmi.
 * Layar di atasnya berkedip saat setThinking(true).
 */
class RobotView(context: Context) : View(context) {

    private val slabCount = 4
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#2B2F33")
    }
    private val light = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7FDBFF")
    }
    private val rect = RectF()
    private var blink: ValueAnimator? = null

    fun setThinking(on: Boolean) {
        blink?.cancel()
        blink = null
        if (on) {
            blink = ValueAnimator.ofInt(255, 50).apply {
                duration = 450
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener {
                    light.alpha = it.animatedValue as Int
                    invalidate()
                }
                start()
            }
        } else {
            light.alpha = 255
            invalidate()
        }
    }

    override fun onDetachedFromWindow() {
        blink?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w * 0.04f
        val slabW = (w - gap * (slabCount - 1)) / slabCount
        val r = w * 0.05f
        edge.strokeWidth = w * 0.025f

        for (i in 0 until slabCount) {
            val left = i * (slabW + gap)
            body.color = Color.parseColor(if (i % 2 == 0) "#B8BEC4" else "#9AA1A8")
            rect.set(left, 0f, left + slabW, h)
            canvas.drawRoundRect(rect, r, r, body)
            canvas.drawRoundRect(rect, r, r, edge)
        }

        val sx = (slabW + gap) + slabW * 0.15f
        val ex = (slabW + gap) * 2f + slabW * 0.85f
        rect.set(sx, h * 0.12f, ex, h * 0.12f + h * 0.07f)
        canvas.drawRoundRect(rect, r, r, light)
    }
}
