package com.example.floatingai

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class OverlayService : Service() {

    // Nama model bisa berubah. Cek daftar terbaru di dokumentasi Gemini API.
    private val MODEL = "gemini-2.5-flash"

    private lateinit var wm: WindowManager
    private lateinit var bubble: View
    private var panel: View? = null
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    private fun startAsForeground() {
        val chId = "floating_ai"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Floating AI", NotificationManager.IMPORTANCE_MIN)
        )
        val notif = Notification.Builder(this, chId)
            .setContentTitle("Floating AI aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    // ---------- Gelembung yang bisa digeser ----------
    private fun addBubble() {
        val tv = RobotView(this)
        bubble = tv
        val lp = WindowManager.LayoutParams(
            dp(44), dp(72), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    lp.x = sx + dx; lp.y = sy + dy
                    wm.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(tv, lp)
    }

    // ---------- Panel chat ----------
    private fun togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.WHITE)
                setStroke(dp(1), Color.LTGRAY)
            }
        }
        val answer = TextView(this).apply {
            setTextColor(Color.BLACK)
            text = "Tanya apa saja..."
        }
        val scroll = ScrollView(this).apply {
            addView(answer)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val input = EditText(this).apply { hint = "Ketik pertanyaan" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply { text = "Kirim" }
        val close = Button(this).apply { text = "Tutup" }
        row.addView(send); row.addView(close)

        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@setOnClickListener
            answer.text = "Berpikir..."
            input.setText("")
            (bubble as? RobotView)?.setThinking(true)
            thread {
                val res = try { askGemini(q) } catch (e: Exception) { "Gagal: ${e.message}" }
                ui.post {
                    answer.text = res
                    (bubble as? RobotView)?.setThinking(false)
                }
            }
        }
        close.setOnClickListener { togglePanel() }

        root.addView(scroll); root.addView(input); root.addView(row)

        // Panel perlu fokus supaya keyboard bisa muncul.
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),
            (resources.displayMetrics.heightPixels * 0.5).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel = root
        wm.addView(root, lp)
    }

    // ---------- Panggil Gemini (REST, tanpa library tambahan) ----------
    private fun askGemini(prompt: String): String {
        val key = getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getString("api_key", "").orEmpty()
        if (key.isEmpty()) return "API key belum diisi. Buka aplikasinya dulu."

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val body = JSONObject().put(
            "contents", JSONArray().put(
                JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", prompt))
                )
            )
        )
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)
            .bufferedReader().use { it.readText() }
        if (code !in 200..299) return "Error $code: $text"

        return JSONObject(text)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
            .getJSONObject(0).getString("text")
    }

    override fun onDestroy() {
        runCatching { wm.removeView(bubble) }
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
}
