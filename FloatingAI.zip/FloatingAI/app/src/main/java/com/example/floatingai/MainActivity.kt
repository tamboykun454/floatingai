package com.example.floatingai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val info = TextView(this).apply {
            text = "1) Ambil API key gratis di aistudio.google.com\n" +
                   "2) Tempel di bawah, lalu simpan\n" +
                   "3) Izinkan 'tampil di atas aplikasi lain'\n" +
                   "4) Nyalakan gelembung"
        }
        val keyInput = EditText(this).apply {
            hint = "Tempel API key di sini"
            setText(prefs.getString("api_key", ""))
            setSingleLine()
        }
        val save = Button(this).apply {
            text = "Simpan key"
            setOnClickListener {
                prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Tersimpan", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "Nyalakan gelembung"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                finish()
            }
        }
        val stop = Button(this).apply {
            text = "Matikan gelembung"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }

        listOf(info, keyInput, save, start, stop).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
